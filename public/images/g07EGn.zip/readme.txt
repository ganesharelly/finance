button text: 
primary color: 000033
gradient color: 330099
width (pixels): 130
height (pixels): 24
corner radius (pixels): 15
text height (points): 12
text color: ffffff
background color: cccccc
font name: DejaVuSans
rollover primary color: 66ffff
rollover gradient color: 6666ff
rollover text color: 000000
quality: 2
image location: none
image height (pixels): 12
image name: 
image foreground color determination: auto
image foreground color: 000000
image transparent color determination: auto
image transparent color: ffffff
url: http://www.glassybuttons.com/buttonmill/glassy.php?button_text=&color=000033&grcolor=330099&width=130&height=24&radius=15&theight=12&tcolor=ffffff&bkcolor=cccccc&fname=DejaVuSans&rcolor=66ffff&rgrcolor=6666ff&rtcolor=000000&imglocate=none&imgheight=12&imgname=&imgfore=auto&imgforecolor=000000&imgtran=auto&imgtrancolor=ffffff&quality=2&fromhere=1
