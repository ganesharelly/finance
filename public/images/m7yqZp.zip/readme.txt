button text: 
primary color: 6a6a6a
gradient color: 6a6a6a
width (pixels): 70
height (pixels): 24
corner radius (pixels): 15
text height (points): 12
text color: ffffff
background color: cccccc
font name: DejaVuSans
rollover primary color: 4a4a4a
rollover gradient color: 4a4a4a
rollover text color: 000000
quality: 2
image location: none
image height (pixels): 12
image name: 
image foreground color determination: auto
image foreground color: 000000
image transparent color determination: auto
image transparent color: 000000
url: http://www.glassybuttons.com/buttonmill/glassy.php?button_text=&color=6a6a6a&grcolor=6a6a6a&width=70&height=24&radius=15&theight=12&tcolor=ffffff&bkcolor=cccccc&fname=DejaVuSans&rcolor=4a4a4a&rgrcolor=4a4a4a&rtcolor=000000&imglocate=none&imgheight=12&imgname=&imgfore=auto&imgforecolor=000000&imgtran=auto&imgtrancolor=000000&quality=2&fromhere=1
